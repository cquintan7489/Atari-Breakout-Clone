// import java libraries
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.geom.Shape;


// Ball class inherits from GameObject
public class Ball extends GameObject {
	// declare class constants
	public static final int LIFEBALL2_YPOS = 695;
	public static final int LIFEBALL1_YPOS = 655;
	public static final int LIFEBALL_XPOS = 1555;
	public static final int INIT_GAMEBALL_VEL = 6;
	public static final int BALL_DIMENSIONS = 20;
	public static final int INIT_GAMEBALL_YPOS = 400;
	public static final int INIT_GAMEBALL_XPOS = 480;
	// class constructor - makes object of the GameObject type
	public Ball(float x, float y, float width, float height, float xVelocity, float yVelocity, Color color) 
	{
		super(x, y, width, height, xVelocity, yVelocity, color);
	}
	// drawIt method draws a ball in the form of a circle with color - overrides the abstract method that the class inherits from
	@Override
	public void drawIt(Graphics painter) 
	{
		Color oldColor = painter.getColor();
		painter.setColor(this.color);
		painter.fillOval(this.x, this.y, this.width, this.height);
		painter.setColor(oldColor);
	}
	// method that moves the ball across the screen
	public void moveIt()
	{
		this.x += xVelocity;
		this.y += yVelocity;
	}
	// method that determines what the object should do upon colliding - overrides the abstract method that the class inherits from
	@Override
	public void OnHit(Object other) 
	{
		// checks to see if an object has collided with the determined object
		if(CheckBoxCollision(other) == true)
		{
				// draws a hit box around the two objects that are colliding
				Shape givingHitBox = new Rectangle(this.x, this.y, this.width, this.height);
				Shape recievingHitBox = new Rectangle(((GameObject) other).getX(), ((GameObject) other).getY(), ((GameObject) other).getWidth(), ((GameObject) other).getHeight());
				
				// based on taking the angle of the incoming ball and the surface it is colliding with and some trig calculations, the x velocity will change accordingly to bounce off dynamically
				// the y velocity will always reverse direction upon collision
				float angle = (float)Math.atan2(recievingHitBox.getCenterY() - givingHitBox.getCenterY(), recievingHitBox.getCenterX() - givingHitBox.getCenterX());
				float speed = (float)Math.sqrt(Math.pow(this.xVelocity, 2) + Math.pow(this.yVelocity, 2));
				this.xVelocity = (float) -(speed*Math.cos(angle));
				this.yVelocity *= -1;

				
			
			
		}
		
		
	}

	

	
	

}
