// import java libraries

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

public class GameMain extends BasicGame 
{
	// declare class constants
	private static final int SCORE_YPOS = 25;
	private static final int SCORE_XPOS = 1455;
	private static final int TEXT_YPOS = 600;
	private static final int TEXT_XPOS = 700;
	private static final int SCREEN_HEIGHT = 900;
	private static final int SCREEN_WIDTH = 1600;
	private static final int SCORE_MULT = 123;
	// declare variables
	private Player playerPaddle;
	private Ball gameBall;
	private Ball lifeBall1;
	private Ball lifeBall2;
	private Brick brickArray[][];
	private int score;
	private int numOfBricks;
	private int keyCount;
	private int deathCounter;
	// GameMain Constructor
	public GameMain(String title) 
	{
		super(title);
		
		
	}

	
	// render method- draws components onto the screen
	@Override
	public void render(GameContainer thisGame, Graphics painter) throws SlickException 
	{
		// draws the player paddle, the game ball, and the life indicator images onto the screen
		playerPaddle.drawIt(painter);
		gameBall.drawIt(painter);
		lifeBall1.drawIt(painter);
		lifeBall2.drawIt(painter);
		// draw instructional starting text onto screen at beginning of game
		if(keyCount == 0)
		{
			painter.drawString("Press Enter To Start" + "\n" + "Use Left And Right Arrow Keys To Move" + "\n" + 
					"Score Is Shown In The Upper Right Corner" + "\n" + 
					"Lives Are Indicated On The Right Side Of The Screen" + "\n" + "Your First Life Is The Inital Ball" + "\n" + 
					"Press Enter To Pause The Game And To Play A New Ball" + "\n" + "Press ESC At Any Time To Restart The Game", TEXT_XPOS, TEXT_YPOS);

		}
		// draw each brick onto the screen 
		for(int i = 1; i < brickArray.length; i++)
		{
			for(int j = 1; j < brickArray[0].length; j++)
			{
				brickArray[i][j].drawIt(painter);
			}
		}
		// draw the score onto the upper right corner of the screen
		painter.drawString("Score: " + score*SCORE_MULT, SCORE_XPOS, SCORE_YPOS);
		// draw the game over screen indication upon losing
		if(deathCounter == 3)
		{
			painter.drawString("Game Over" + "\n" + "Score: " + score*SCORE_MULT + "\n" + "Press ESC To Play Again", TEXT_XPOS, TEXT_YPOS);
			
		}
		// draw the winning indication text upon winning the game
		if(numOfBricks == 0)
		{
			painter.drawString("You've Won!" + "\n" + "Score: " + score*SCORE_MULT + "\n" + "Press ESC To Play Again", TEXT_XPOS, TEXT_YPOS);
		}

		
	}
	// initialize method- creates components to be implemented
	@Override
	public void init(GameContainer thisGame) throws SlickException 
	{
		// instantiate Game Objects- includes the player paddle, game ball, and life ball indication images
		playerPaddle = new Player(Player.INIT_PLAYER_XPOS, Player.INIT_PLAYERYPOS, Player.PLAYER_WIDTH, Player.PLAYER_HEIGHT, Player.INIT_PLAYER_VEL, Player.INIT_PLAYER_VEL, Color.lightGray);
		gameBall = new Ball(Ball.INIT_GAMEBALL_XPOS, Ball.INIT_GAMEBALL_YPOS, Ball.BALL_DIMENSIONS, Ball.BALL_DIMENSIONS, Ball.INIT_GAMEBALL_VEL, Ball.INIT_GAMEBALL_VEL, Color.cyan);
		lifeBall1 = new Ball(Ball.LIFEBALL_XPOS, Ball.LIFEBALL1_YPOS, Ball.BALL_DIMENSIONS, Ball.BALL_DIMENSIONS, Ball.ZERO_VEL, Ball.ZERO_VEL, Color.cyan);
		lifeBall2 = new Ball(Ball.LIFEBALL_XPOS, Ball.LIFEBALL2_YPOS, Ball.BALL_DIMENSIONS, Ball.BALL_DIMENSIONS, Ball.ZERO_VEL, Ball.ZERO_VEL, Color.cyan);
		// set various game logic counters to zero
		numOfBricks = 0;
		keyCount = 0;
		score = 0;
		deathCounter = 0;
		// instantiate Bricks into the game
		brickArray = new Brick[Brick.BRICK_ROW_NUM][Brick.BRICK_COLUMN_NUM];
		for(int i = 1; i < brickArray.length; i++)
		{
			for(int j = 1; j < brickArray[0].length; j++)
			{
				brickArray[i][j] = new Brick(i*Brick.BRICK_XPOS_MULT-Brick.BRICK_SPACING_OFFSET,j*Brick.BRICK_YPOS_MULT, Brick.BRICK_WIDTH, Brick.BRICK_HEIGHT, Brick.ZERO_VEL, Brick.ZERO_VEL, Color.green);
				// brick number counter increases as each brick is created
				numOfBricks++;
				

			}
		}
		
		
	}
	// update method- updates the game screen frame by frame based on the following logic
	@Override
	public void update(GameContainer thisGame, int frameCount) throws SlickException 
	{
		// create input variable 
		Input input = thisGame.getInput();
		// create if input stream to control game and game objects
		if(input.isKeyPressed(Input.KEY_ENTER))
		{
			// each time the enter key is pressed, the key count increases, effectively keeping count
			keyCount++;
		}
		// if condition indicates when the game is not paused. If the key count is even, then the game is paused/not running.
		if(keyCount % 2 != 0)
		{
			// initially making the ball move
			gameBall.moveIt();
			// if statements dictate that the paddle moves left when the left key is pressed, and moves right when the right key is pressed
			if(input.isKeyDown(Input.KEY_LEFT))
			{
				playerPaddle.MoveLeft();
			}
			if(input.isKeyDown(Input.KEY_RIGHT))
			{
				playerPaddle.MoveRight();
			}
			
		}
		
		// establishes the bounds of the player paddle and does not allow it to go past.
		playerPaddle.playerBounds();
		
		
		// checks the bounds of the game ball and reverses the velocities if it touches the bounds.
		gameBall.CheckBounds();
		// dictates what the game ball should do if it collides with the player paddle - Bounces off based on trig calculations.
		gameBall.OnHit(playerPaddle);
		// dictates what the game ball should do if it collides with a brick - Bounces off based on trig calculations.

		for(int i = 1; i < brickArray.length; i++)
		{
			for(int j = 1; j < brickArray[0].length; j++)
			{
				gameBall.OnHit(brickArray[i][j]);

			}
		}
		// dictates what the brick should do if it collides with the game ball - Brick hit points go to zero and time hit counter increases by 1.
		for(int i = 1; i < brickArray.length; i++)
		{
			for(int j = 1; j < brickArray[0].length; j++)
			{
				brickArray[i][j].OnHit(gameBall);
			}
		}
		// dictates that if a bricks hit points are zero, the brick disappears via removed off the screen
		for(int i = 1; i < brickArray.length; i++)
		{
			for(int j = 1; j < brickArray[0].length; j++)
			{
				if(brickArray[i][j].getHitPoints() == 0)
				{
					
					brickArray[i][j].setX(Brick.BRICK_REMOVE_POS);
					brickArray[i][j].setY(Brick.BRICK_REMOVE_POS);
					
				}
				
			}
		}
		// decreases the number of bricks count and adds to the score by counting how many bricks get hit
		for(int i = 1; i < brickArray.length; i++)
		{
			for(int j = 1; j < brickArray[0].length; j++)
			{
				numOfBricks -= brickArray[i][j].getTimesHit();
				score += brickArray[i][j].getTimesHit();
			}
		}
		// if statement to reset the game components such as game ball placement, game ball velocity, and paddle placement as the ball goes past the paddle
		// also increases the death counter to keep track of times the player has let the game ball past the paddle
		// pauses the game upon letting the game ball past
		
		if(gameBall.getY() > SCREEN_HEIGHT)
		{
			gameBall.setX(playerPaddle.getX() + playerPaddle.getWidth()/2);
			gameBall.setY(Ball.INIT_GAMEBALL_YPOS);
			gameBall.setxVelocity(Ball.INIT_GAMEBALL_VEL);
			gameBall.setyVelocity(Ball.INIT_GAMEBALL_VEL);
			keyCount++;
			deathCounter++;
		}
		// upon the player's first "death", one of the life ball indicators is removed from the screen
		if(deathCounter == 1)
		{
			lifeBall2.setX(Ball.REMOVE_POS);
			lifeBall2.setY(Ball.REMOVE_POS);
			
		}
		// upon the player's second "death", the other life ball indicator is removed from the screen
		if(deathCounter == 2)
		{
			lifeBall1.setX(Ball.REMOVE_POS);
			lifeBall1.setY(Ball.REMOVE_POS);
			
		}
		// upon using up all of the player's lives or the player wins the game by hitting each brick, the paddle and the game ball are removed from the screen
		if(deathCounter == 3 && keyCount % 2 == 0 || numOfBricks == 0)
		{
			playerPaddle.setX(Player.REMOVE_POS);
			playerPaddle.setY(Player.REMOVE_POS);
			gameBall.setX(Ball.REMOVE_POS);
			gameBall.setY(Ball.REMOVE_POS);
			

		}
		// any time the esc key is pressed, the game container is reinitialized, effectively restarting the game
		if(input.isKeyPressed(Input.KEY_ESCAPE))
		{

			thisGame.reinit();
			
		}

						

	}
	// main method
	public static void main(String[] args) 
	{
		// try/catch block to run the game container through Slick 2D
		try
		{
			AppGameContainer thisGame = new AppGameContainer(new GameMain("Break Out"));
			thisGame.setDisplayMode(SCREEN_WIDTH, SCREEN_HEIGHT, false);
			thisGame.setTargetFrameRate(60);
			thisGame.start();
		}
		catch(SlickException exception)
		{
			System.out.println(exception.toString());
		}
	}

}
