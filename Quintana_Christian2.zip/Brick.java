// import java libraries
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
// Brick class inherits from GameObject class
public class Brick extends GameObject 
{
	// declare class constants
	public static final int BRICK_YPOS_MULT = 65;
	public static final int BRICK_SPACING_OFFSET = 122;
	public static final int BRICK_XPOS_MULT = 142;
	public static final int BRICK_HEIGHT = 60;
	public static final int BRICK_WIDTH = 137;
	public static final int BRICK_COLUMN_NUM = 6;
	public static final int BRICK_ROW_NUM = 12;
	public static final int BRICK_REMOVE_POS = -500;
	// declare class variables
	private float hitPoints;
	private float timesHit;
	// class constructor - makes object of the GameObject type
	// sets hit point amount
	public Brick(float x, float y, float width, float height, float xVelocity, float yVelocity, Color color) 
	{
		super(x, y, width, height, xVelocity, yVelocity, color);
		this.hitPoints = 10;

	}
	// method that draws the brick into the screen as a colored rectangle - overrides the abstract method that the class inherits from
	@Override
	public void drawIt(Graphics painter) 
	{
		Color oldColor = painter.getColor();
		painter.setColor(this.color);
		painter.fillRect(this.x, this.y, this.width, this.height);
		painter.setColor(oldColor);
		this.timesHit = 0;

	}
	// method that determines what the brick should do upon collision - overrides the abstract method that the class inherits from
	@Override
	public void OnHit(Object other) 
	{
		// checks if the bricks has been hit
		if (CheckBoxCollision(other) == true)
		{
			// hit points go to zero and the times hit counter increments by one
			hitPoints = 0;
			timesHit++;
			
			
		}
	}
	// getter for hit points variable
	public float getHitPoints() 
	{
		return hitPoints;
	}
	// getter for times hit variable
	public float getTimesHit()
	{
		return timesHit;
	}

	

}
