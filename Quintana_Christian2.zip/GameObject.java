// import java libraries
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.geom.*;

// abstract GameObject class
public abstract class GameObject 
{
	// declare abstract class constants
	public final static int REMOVE_POS = -200;
	public final static int ZERO_VEL = 0;
	// declare abstract class variables
	protected float x;
	protected float y;
	protected float width;
	protected float height;
	protected float xVelocity;
	protected float yVelocity;
	protected Color color;
	
	// class constructor
	public GameObject(float x, float y, float width, float height, float xVelocity, float yVelocity, Color color)
	{
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.xVelocity = xVelocity;
		this.yVelocity = yVelocity;
		this.color = color;
	}
	// abstract drawIt method - draws object to string based upon specific class definitions of drawIt
	public abstract void drawIt(Graphics painter);
	// abstract OnHit method - determines what to do if an object collides with another object - specified in individual class
	public abstract void OnHit(Object other);
	// method that checks whether a game object has collided with another game object
	public boolean CheckBoxCollision(Object other)
	{
		boolean check = false;
		// checks if the other object is of type GameObject
		if(other instanceof GameObject)
		{
			
			// draws hit box around game objects to detect their intersection of each other
			Shape givingHitBox = new Rectangle(this.x, this.y, this.width, this.height);
			Shape recievingHitBox = new Rectangle(((GameObject) other).getX(), ((GameObject) other).getY(), ((GameObject) other).getWidth(), ((GameObject) other).getHeight());
			
			if(givingHitBox.intersects(recievingHitBox))
			{
				check = true;
			}
			
			
			
		}
		return check;
	}
	
	// method that sets the bounds for game objects and reverses their velocities if they hit the bound distance so that they bounce off the screen and stay in bounds
	public void CheckBounds()
	{
		if(this.x <= 0)
		{
			this.xVelocity *= -1;
		}
		if(this.x + this.width >= 1600)
		{
			this.xVelocity *= -1;
		}
		if(this.y <= 0)
		{
			this.yVelocity *= -1;
		}
		
		
	}
	// the rest of the methods below are getter and setter methods for the variables created in the constructor. Width and height do not have setter methods
	public float getX() 
	{
		return x;
	}

	public void setX(float x) 
	
	{
		this.x = x;
	}

	public float getY() 
	{
		return y;
	}

	public void setY(float y) 
	{
		this.y = y;
	}

	public float getxVelocity() 
	{
		return xVelocity;
	}

	public void setxVelocity(float xVelocity) 
	{
		this.xVelocity = xVelocity;
	}

	public float getyVelocity() 
	{
		return yVelocity;
	}

	public void setyVelocity(float yVelocity) 
	{
		this.yVelocity = yVelocity;
	}

	public Color getColor() 
	{
		return color;
	}

	public void setColor(Color color) 
	{
		this.color = color;
	}

	public float getWidth() 
	{
		return width;
	}

	public float getHeight() 
	{
		return height;
	}

	
	
	
	
	
	
}
