// import java libraries
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;


// player class inherits from GameObject
public class Player extends GameObject {
	// declare class constants
	public static final int INIT_PLAYER_VEL = 12;
	public static final int PLAYER_HEIGHT = 30;
	public static final int PLAYER_WIDTH = 250;
	public static final int INIT_PLAYERYPOS = 800;
	public static final int INIT_PLAYER_XPOS = 640;
	// class constructor - makes object of the GameObject type
	public Player(float x, float y, float width, float height, float xVelocity, float yVelocity, Color color) 
	{
		super(x, y, width, height, xVelocity, yVelocity, color);
	}
	// drawIt method draws the paddle in the form of a rectangle with color onto the screen - overrides the abstract method that the class inherits
	@Override
	public void drawIt(Graphics painter) 
	{
		Color oldColor = painter.getColor();
		painter.setColor(this.color);
		painter.fillRect(this.x, this.y, this.width, this.height);
		painter.setColor(oldColor);
	}
	// OnHit method that determines what the object should do upon collision. Player does nothing upon collision. Overrides the abstract method that the class inherits 
	@Override
	public void OnHit(Object other) 
	{
		
	}
	// method that moves the player right
	public void MoveRight()
	{
		this.x += this.xVelocity;
	}
	// method that moves the player left
	public void MoveLeft()
	{
		this.x -= this.yVelocity;
	}
	// method that restricts the player from moving off the screen and keeps velocity direction intact
	public void playerBounds()
	{
		if(this.x <= 0)
		{
			this.x = 0;
		}
		if(this.x + this.width >= 1600)
		{
			this.x  = 1600 - this.width;
		}
	}
	
}
